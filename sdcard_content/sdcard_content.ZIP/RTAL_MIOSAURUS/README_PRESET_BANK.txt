RTAL MIOSAURUS FACTORY BANK 128

Target firmware:
RTAL MIOSAURUS SYNTECH GUI V0.12 SD PRESETS

Installation:
Copy the complete RTAL_MIOSAURUS directory to the root of the microSD card.

Preset files:
RTAL_MIOSAURUS/PRESETS/P000.rtal ... P127.rtal

Bank layout:
P000-P015  Deep / Sub
P016-P031  Classic Analog
P032-P047  Acid / Resonant
P048-P063  PWM / Motion
P064-P079  Pluck / Sequence
P080-P095  Para
P096-P111  FX / Space
P112-P127  Experimental / Performance

File format:
Header: 16 bytes
Payload: 224 bytes
Total per preset: 240 bytes
CRC32 verified for all 128 files.

Notes:
- P000 maps to MIDI Program Change 0.
- P127 maps to MIDI Program Change 127.
- Preset names are embedded in each .rtal file.
- LAST_SLOT.bin and MIDI_LEARN.bin are intentionally not included; the firmware manages these separately.
